var1=10
var2=20

sum='expr $var1 + $var2'
echo $sum
