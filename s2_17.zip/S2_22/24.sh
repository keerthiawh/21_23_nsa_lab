echo "enter a file name"
read file
tac $file
