echo "enter a character"
read n
case $n in

        a)
        echo "it is a vowel"
        ;;

        e)
        echo "it is a vowel"
        ;;

        i)
        echo "it is a vowel"
        ;;

        o)
        echo "it is a vowel"
        ;;

        u)
        echo "it is a vowel"
        ;;
	 *)
        echo "it is not a vowel"
        ;;
esac


